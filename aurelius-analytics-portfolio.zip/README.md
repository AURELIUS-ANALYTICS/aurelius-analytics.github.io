# Thapedi Seleka - AWS Portfolio

This is my beginner AWS cloud portfolio hosted with GitHub Pages.

## Sections:
- **About Me**: Introduction and goals
- **Certifications**: AWS certifications and milestones
- **Projects**: Cloud projects (S3, EC2, etc.)
- **Contact**: Email and future social links

## How to Edit:
- Modify `index.html` with your latest updates.
- Use GitHub Desktop or upload directly via browser.
- Enable GitHub Pages in repository settings.

Visit: https://aurelius-analytics.github.io after publishing!
